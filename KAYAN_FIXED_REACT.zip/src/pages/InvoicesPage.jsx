export default function InvoicesPage() {
  return (
    <main style={{ padding: 30, fontFamily: 'sans-serif' }}>
      <h1>📄 فواتيري</h1>
      <p>دي صفحة الفواتير، ح نعرض فيها قائمة فواتيرك بالكامل.</p>
    </main>
  );
}